var menudata={children:[
{text:"Página principal",url:"index.html"}]}
